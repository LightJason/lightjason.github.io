package myagentproject;

import org.lightjason.agentspeak.common.CPath;
import org.lightjason.agentspeak.common.IPath;
import org.lightjason.agentspeak.action.IBaseAction;
import org.lightjason.agentspeak.language.execution.IContext;
import org.lightjason.agentspeak.language.ITerm;
import org.lightjason.agentspeak.language.CRawTerm;
import org.lightjason.agentspeak.language.execution.fuzzy.CFuzzyValue;
import org.lightjason.agentspeak.language.execution.fuzzy.IFuzzyValue;

import java.util.List;
import java.util.Locale;
import java.text.MessageFormat;

public final class MyAction extends IBaseAction
{
    @Override
    public final IPath name()
    {
        return CPath.from( "my/cool-action" );
    }

    @Override
    public final int minimalArgumentNumber()
    {
        return 1;
    }

    @Override
    public final IFuzzyValue<Boolean> execute( final IContext p_context, final boolean p_parallel, final List<ITerm> p_argument, final List<ITerm> p_return,
                                               final List<ITerm> p_annotation )
    {
        // Convert term-value to a Java-type (here String) and create a lower-case string.
        // Note: You don't have to think about the term definition, LightJason does this for you.
        // But it will throw a casting exception if the type of the passed argument is incorrect.
        final String l_argument = p_argument.get( 0 ).<String>raw().toLowerCase( Locale.ROOT );

        // here we do some testing output stuff and the context parameter contains all information
        // in which context the action is called e.g. the agent which calls, current variables, ...
        System.out.println( MessageFormat.format(
                "standalone action is called from agent {0} with argument \"{1}\"", p_context.agent(), l_argument
        ) );

        // the action should return a value, you can wrap any Java object into LightJasons's terms.
        p_return.add( CRawTerm.from( l_argument ) );

        // actions returns a fuzzy-boolean for successful or failed execution
        // the optional second parameter is a fuzzy-value in [0,1]. default: 1
        return CFuzzyValue.from( true );
    }
}
