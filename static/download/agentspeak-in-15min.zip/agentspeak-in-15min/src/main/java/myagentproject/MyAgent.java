package myagentproject;

import org.lightjason.agentspeak.agent.IBaseAgent;
import org.lightjason.agentspeak.configuration.IAgentConfiguration;
import org.lightjason.agentspeak.action.binding.IAgentAction;
import org.lightjason.agentspeak.action.binding.IAgentActionFilter;
import org.lightjason.agentspeak.action.binding.IAgentActionName;

import java.text.MessageFormat;

// annotation to mark the class, that actions are inside
@IAgentAction
public final class MyAgent extends IBaseAgent<MyAgent>
{
    // constructor of the agent
    // @param p_configuration agent configuration of the agent generator
    public MyAgent( final IAgentConfiguration<MyAgent> p_configuration )
    {
        super( p_configuration );
    }

    // an inner action inside the action class,
    // with the annotation the method is marked as action
    // and the action-name for the ASL script is set
    // @param p_value argument of the action
    // @note LightJason supports Long and Double values, so if you declare
    // every numerical value als Number you can handle both types, because
    // number has methods to convert the data
    @IAgentActionFilter
    @IAgentActionName( name = "my/very-cool-action" )
    private void myaction( final Number p_value )
    {
        System.out.println( MessageFormat.format( "inner action is called with value {0} by agent {1}", p_value, this ) );
    }

}