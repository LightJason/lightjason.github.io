package myagentproject;

import org.lightjason.agentspeak.action.binding.IAgentAction;
import org.lightjason.agentspeak.action.binding.IAgentActionFilter;
import org.lightjason.agentspeak.action.binding.IAgentActionName;
import org.lightjason.agentspeak.agent.IBaseAgent;
import org.lightjason.agentspeak.configuration.IAgentConfiguration;
import org.lightjason.agentspeak.language.CLiteral;
import org.lightjason.agentspeak.language.CRawTerm;
import org.lightjason.agentspeak.language.instantiable.plan.trigger.CTrigger;
import org.lightjason.agentspeak.language.instantiable.plan.trigger.ITrigger;

import java.text.MessageFormat;


/**
 * agent class with annotation to mark the class that actions are inside
 */
@IAgentAction
public final class MyAgent extends IBaseAgent<MyAgent>
{
    /**
     * constructor of the agent
     *
     * @param p_configuration agent configuration of the agent generator
     **/
    public MyAgent( final IAgentConfiguration<MyAgent> p_configuration )
    {
        super( p_configuration );
    }

    /**
     * overload agent-cycle
     *
     * @return agent self-reference
     */
    @Override
    public final MyAgent call() throws Exception
    {
        // create goal trigger based on a condition
        this.trigger(
                CTrigger.from(
                        ITrigger.EType.ADDGOAL,
                        CLiteral.from(
                                "special-goal",
                                CRawTerm.from( 2342 )
                        )
                )
        );

        // run default cycle
        return super.call();
    }

    /**
     *  an inner action inside the agent class,
     * with the annotation that the method is marked as action
     * and the action-name for the ASL script is set
     *
     * @note LightJason supports Long and Double values, so if you declare
     * every numerical value as Number you can handle both types, because
     * number has methods to convert the data
     *
     * @param p_value argument of the action
     */
    @IAgentActionFilter
    @IAgentActionName( name = "my/very-cool-action" )
    private void myaction( final Number p_value )
    {
        System.out.println( MessageFormat.format( "inner action is called with value {0} by agent {1}", p_value, this ) );
    }
}
