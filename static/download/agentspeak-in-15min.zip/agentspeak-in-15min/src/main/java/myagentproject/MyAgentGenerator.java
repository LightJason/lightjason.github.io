package myagentproject;

import org.lightjason.agentspeak.common.CCommon;
import org.lightjason.agentspeak.generator.IBaseAgentGenerator;
import org.lightjason.agentspeak.language.score.IAggregation;

import java.util.stream.Stream;
import java.io.InputStream;
import java.util.stream.Collectors;


/* agent generator to create agents */
public final class MyAgentGenerator extends IBaseAgentGenerator<MyAgent>
{
    /**
     * @param p_stream ASL code as any stream e.g. FileInputStream
     */
    public MyAgentGenerator( final InputStream p_stream ) throws Exception
    {
        super(
            // input ASL stream
            p_stream,
            // a set with all possible actions for the agent
            Stream.concat(
                // we use all build-in actions of LightJason
                CCommon.actionsFromPackage(),
                Stream.concat(
                    // use the actions which are defined inside the agent class
                    CCommon.actionsFromAgentClass( MyAgent.class ),
                    // add an own external action
                    Stream.of(
                        new MyAction()
                    )
                )
            // build the set with a collector
            ).collect( Collectors.toSet() ),
            // aggregation function for the optimization function, here
            // we use an empty function
            IAggregation.EMPTY
        );
    }

    /**
     * generator method of the agent
     *
     * @param p_data any data which can be put from outside to the generator method
     * @return returns an agent
     */
    @Override
    public final MyAgent generatesingle( final Object... p_data )
    {
        return new MyAgent( m_configuration );
    }
}
