package myagentproject;

import org.lightjason.agentspeak.agent.IAgent;

import java.io.FileInputStream;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


/**
 * main application with runtime
 */
public final class App
{

    /**
     * private constructor to avoid any instantiation
     */
    private App()
    {
    }


    /**
     * main method
     *
     * @param p_args command-line arguments
     */
    public static void main( final String[] p_args )
    {
        // global set with agents
        final Set<IAgent<?>> l_agents;

        try
        (
            // stream woth ASL code
            final FileInputStream l_stream = new FileInputStream( p_args[0] );
        )
        {
            l_agents = Collections.unmodifiableSet(
                    // create agent generator with send-action
                    new MyAgentGenerator( new CSend(), l_stream )
                    // generate multiple agents
                    .generatemultiple( Integer.parseInt(p_args[1]) )
                    // create set
                    .collect( Collectors.toSet() )
            );
        }
        catch (final Exception l_exception)
        {
            l_exception.printStackTrace();
            return;
        }


        IntStream
            // define cycle range, i.e. number of cycles to run sequentially
            .range(
                0,
                p_args.length < 3
                ? Integer.MAX_VALUE
                : Integer.parseInt( p_args[2] )
            )
            .forEach( j -> {
                System.out.println();

                // iterate in parallel over all agents
                l_agents.parallelStream().forEach( i -> {
                    try
                    {
                        // call each agent, i.e. trigger a new agent cycle
                        i.call();
                    }
                    catch ( final Exception l_exception )
                    {
                        l_exception.printStackTrace();
                        throw new RuntimeException();
                    }
                } );
            } );

    }
}
