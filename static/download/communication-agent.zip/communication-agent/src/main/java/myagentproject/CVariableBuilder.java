package myagentproject;

import org.lightjason.agentspeak.agent.IAgent;
import org.lightjason.agentspeak.language.execution.IVariableBuilder;
import org.lightjason.agentspeak.language.instantiable.IInstantiable;
import org.lightjason.agentspeak.language.variable.CConstant;
import org.lightjason.agentspeak.language.variable.IVariable;

import java.util.stream.Stream;

/**
 * variable build, to create a constant variable with the agent name
 */
public final class CVariableBuilder implements IVariableBuilder
{
    @Override
    public final Stream<IVariable<?>> generate(IAgent<?> p_agent, IInstantiable p_runningcontext )
    {
        return Stream.of(
            new CConstant<>( "MyName", p_agent.<MyCommunicationAgent>raw().name() )
        );
    }
}
