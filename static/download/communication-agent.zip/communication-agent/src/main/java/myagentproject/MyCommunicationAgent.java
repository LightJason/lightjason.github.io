package myagentproject;


import org.lightjason.agentspeak.agent.IBaseAgent;
import org.lightjason.agentspeak.configuration.IAgentConfiguration;

/**
 * agent, here in detail an communication agents with an individual name
 */
public final class MyCommunicationAgent extends IBaseAgent<MyCommunicationAgent>
{
    /**
     *   agent name
     */
    private final String m_name;

    /**
     * constructor of the agent
     *
     * @param p_name agent name
     * @param p_configuration agent configuration of the agent generator
     */
    public MyCommunicationAgent( final String p_name, final IAgentConfiguration<MyCommunicationAgent> p_configuration )
    {
        super( p_configuration );
        m_name = p_name;
    }

    /**
     * returns the agent name
     *
     * @return agent name
     */
    public final String name()
    {
        return m_name;
    }

}